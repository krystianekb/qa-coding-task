#!/bin/sh

$JAVA_HOME/bin/java -jar ./lib/trade-validation-service-*.jar